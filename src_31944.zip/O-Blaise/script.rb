#!/usr/bin/env ruby

def compiler()
	`mcs /target:library Runtime.cs`
	Dir.open('./tests/').each do |file|
		begin
			if File.extname(file) == ".blaise" then
				`./blaise -c ./tests/#{file} > blaise.il`
				puts "%%%%%%%%%%%%%%%%%%%%%%%%          RUNNING        %%%%%%%%%%%%"
				puts file+"\n"
				puts "%%%%%%%%%%%%%%%%%%%%%%%%           OUTPUT        %%%%%%%%%%%%"
				`ilasm blaise.il`
				puts `mono blaise.exe < ./tests/#{File.basename(file, ".blaise") + ".in"}`
				puts "%%%%%    SHOULD BE   %%%%%%%%"
				puts `tee <./tests/#{File.basename(file, ".blaise") + ".out"}`
				puts "%%%%%%%%%%%%%%%%%%%%%%%%           ENDED         %%%%%%%%%%%%"
				puts "\n\n"
			end
		end
	end
	`rm Runtime.dll blaise.exe`
end

def interpreter()
	Dir.open('./tests/').each do |file|
		begin
			if File.extname(file) == ".blaise" then
				puts "%%%%%%%%%%%%%%%%%%%%%%%%          RUNNING        %%%%%%%%%%%%"
				puts file+"\n"
				puts "%%%%%%%%%%%%%%%%%%%%%%%%           OUTPUT        %%%%%%%%%%%%"
				puts `./blaise -i ./tests/#{file} < ./tests/#{File.basename(file, ".blaise") + ".in"}`
				puts "%%%%%    SHOULD BE   %%%%%%%%"
				puts `tee <./tests/#{File.basename(file, ".blaise") + ".out"}`
				puts "%%%%%%%%%%%%%%%%%%%%%%%%           ENDED         %%%%%%%%%%%%"
				puts "\n\n"
			end
		end
	end
end

if ARGV[0] == "i" then
	interpreter()
else
	compiler()
end
